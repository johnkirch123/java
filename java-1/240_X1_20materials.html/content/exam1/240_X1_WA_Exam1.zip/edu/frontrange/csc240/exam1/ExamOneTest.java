package edu.frontrange.csc240.exam1;

public class ExamOneTest
{
	public static void main( String args[] ) 
	{
		AccountTester testOne = new AccountTester();
		testOne.testAccountClass();
	}
} 
